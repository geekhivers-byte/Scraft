# ScraftX Chatbot Setup Guide

## 🤖 Getting Started with Google Gemini Integration

### Step 1: Get Your Google Gemini API Key
1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign up or log in to your Google account
3. Click "Create API Key"
4. Copy your API key (keep it secure!)

### Step 2: Configure Your Environment
1. Open the `.env` file in your project root
2. Replace `your_gemini_api_key_here` with your actual API key:
   ```
   REACT_APP_GEMINI_API_KEY=your-actual-gemini-api-key-here
   ```
3. Save the file

### Step 3: Restart Your Development Server
```bash
npm start
```

## ✨ Chatbot Features

### 🚀 Quick Actions
- **Show Products**: Instant product recommendations
- **Artisan Stories**: Learn about craft traditions
- **Festival Sales**: Discover seasonal collections

### 🧠 Smart Responses
- **Instant Answers**: Pre-configured responses for common queries
- **AI-Powered Chat**: Full Google Gemini integration for complex questions
- **Context Awareness**: Remembers conversation history
- **Scraft-Focused**: Specialized knowledge about Indian handicrafts

### 🎨 User Experience
- **Floating Chat Button**: Easy access from any page
- **Typing Indicators**: Real-time conversation feel
- **Message History**: Persistent chat sessions
- **Mobile Responsive**: Works on all devices

## 🔧 Usage Instructions

1. **Click the chat button** (bottom-right corner)
2. **Start chatting** - type your question or use quick actions
3. **Get instant help** with products, artisan stories, or general queries
4. **Enjoy personalized recommendations** based on your interests

## 📝 Notes

- Without an API key, you'll get helpful pre-configured responses
- With an API key, you get full Google Gemini-powered conversations
- All conversations are stored locally in your browser
- The chatbot is specifically trained on Scraft's product knowledge

## 🎯 Perfect for:
- Product discovery and recommendations
- Learning about Indian handicrafts and artisan techniques
- Getting care instructions for handmade items
- Finding festival-specific collections
- General customer support

---
*Happy crafting with ScraftX! 🎨✨*
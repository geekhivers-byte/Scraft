import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import artisanWorkshop from '../assets/artisan-workshop.jpg';
import { useCart } from '../contexts/CartContext';

const ShopPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { addItem, openCart } = useCart();

  // Categories with icons
  const categories = [
    { id: 'pots', name: 'Pottery & Ceramics', icon: '🏺', description: 'Handcrafted clay pots and ceramic art' },
    { id: 'sarees', name: 'Sarees & Textiles', icon: '🥻', description: 'Traditional handwoven fabrics' },
    { id: 'toys', name: 'Wooden Toys', icon: '🪀', description: 'Eco-friendly handmade toys' },
    { id: 'jewelry', name: 'Jewelry', icon: '💍', description: 'Silver and traditional ornaments' },
    { id: 'home-decor', name: 'Home Decor', icon: '🏠', description: 'Beautiful decorative items' },
    { id: 'bags', name: 'Bags & Accessories', icon: '👜', description: 'Handwoven bags and accessories' }
  ];

  // Bestsellers
  const bestsellers = [
    {
      id: 1,
      name: "Handwoven Silk Saree",
      price: "₹4,999",
      originalPrice: "₹7,999",
      image: artisanWorkshop,
      rating: 4.8,
      reviews: 124,
      badge: "Bestseller",
      category: "sarees",
      productId: "silk-saree-1"
    },
    {
      id: 2,
      name: "Traditional Clay Pot Set",
      price: "₹1,299",
      originalPrice: "₹1,899",
      image: artisanWorkshop,
      rating: 4.9,
      reviews: 89,
      badge: "Top Rated",
      category: "pots",
      productId: "ceramic-vase-1"
    },
    {
      id: 3,
      name: "Wooden Educational Toys",
      price: "₹899",
      originalPrice: "₹1,299",
      image: artisanWorkshop,
      rating: 4.7,
      reviews: 156,
      badge: "Eco-Friendly",
      category: "toys",
      productId: "wooden-toy-1"
    },
    {
      id: 4,
      name: "Silver Temple Jewelry",
      price: "₹3,499",
      originalPrice: "₹4,999",
      image: artisanWorkshop,
      rating: 4.9,
      reviews: 67,
      badge: "Premium",
      category: "jewelry",
      productId: "silver-jewelry-1"
    }
  ];

  // Product Gallery
  const products = [
    {
      id: 1,
      name: "Handwoven Silk Saree",
      price: "₹4,999",
      originalPrice: "₹7,999",
      image: artisanWorkshop,
      category: "sarees",
      isNew: false,
      discount: "38% OFF",
      productId: "silk-saree-2"
    },
    {
      id: 2,
      name: "Traditional Clay Pot Set",
      price: "₹1,299",
      originalPrice: "₹1,899",
      image: artisanWorkshop,
      category: "pots",
      isNew: true,
      discount: "32% OFF",
      productId: "ceramic-vase-2"
    },
    {
      id: 3,
      name: "Wooden Educational Toys",
      price: "₹899",
      originalPrice: "₹1,299",
      image: artisanWorkshop,
      category: "toys",
      isNew: false,
      discount: "31% OFF",
      productId: "wooden-toy-2"
    },
    {
      id: 4,
      name: "Silver Temple Jewelry",
      price: "₹3,499",
      originalPrice: "₹4,999",
      image: artisanWorkshop,
      category: "jewelry",
      isNew: true,
      discount: "30% OFF",
      productId: "silver-jewelry-2"
    },
    {
      id: 5,
      name: "Decorative Wall Hanging",
      price: "₹1,599",
      originalPrice: "₹2,299",
      image: artisanWorkshop,
      category: "home-decor",
      isNew: false,
      discount: "30% OFF",
      productId: "ceramic-vase-3"
    },
    {
      id: 6,
      name: "Handwoven Jute Bag",
      price: "₹799",
      originalPrice: "₹1,199",
      image: artisanWorkshop,
      category: "bags",
      isNew: true,
      discount: "33% OFF",
      productId: "silk-saree-3"
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-deep-espresso to-terracotta-brown text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-playfair text-5xl font-bold mb-6 tracking-wide">Shop Our Collections</h1>
          <p className="font-inter text-xl max-w-3xl mx-auto leading-relaxed">
            Discover authentic handcrafted treasures from skilled artisans across India. 
            Each piece tells a story of tradition, culture, and exceptional craftsmanship.
          </p>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-warm-cream">
        <div className="container mx-auto px-4">
          <h2 className="font-playfair text-4xl font-bold text-center text-deep-espresso mb-12 tracking-wide">
            Shop by Category
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => (
              <Link 
                key={category.id}
                to={`/shop/${category.id}`}
                className="group cursor-pointer bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-transparent hover:border-golden-tan block"
              >
                <div className="text-center">
                  <div className="text-6xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {category.icon}
                  </div>
                  <h3 className="font-playfair text-xl font-bold text-deep-espresso mb-3 tracking-wide">
                    {category.name}
                  </h3>
                  <p className="font-inter text-terracotta-brown text-sm leading-relaxed">
                    {category.description}
                  </p>
                  <div className="mt-4 text-sm font-medium text-terracotta-brown opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    View Products →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Bestsellers Section */}
      <section className="py-16 bg-gradient-to-br from-golden-tan to-warm-cream">
        <div className="container mx-auto px-4">
          <h2 className="font-playfair text-4xl font-bold text-center text-deep-espresso mb-12 tracking-wide">
            ⭐ Bestsellers
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {bestsellers.map((product) => (
              <Link key={product.id} to={`/product/${product.productId}`} className="group bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-3 transition-all duration-300 hover:shadow-2xl block">
                {/* Product Image */}
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-deep-red-clay text-white px-3 py-1 rounded-full text-xs font-bold">
                      {product.badge}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4 bg-white bg-opacity-90 px-2 py-1 rounded-full">
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-500 text-sm">⭐</span>
                      <span className="text-xs font-bold text-deep-espresso">{product.rating}</span>
                    </div>
                  </div>
                </div>
                
                {/* Product Info */}
                <div className="p-6">
                  <h3 className="font-playfair text-lg font-bold text-deep-espresso mb-2 tracking-wide">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="font-inter text-lg font-bold text-deep-red-clay">
                      {product.price}
                    </span>
                    <span className="font-inter text-sm text-gray-400 line-through">
                      {product.originalPrice}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-inter text-xs text-gray-600">
                      {product.reviews} reviews
                    </span>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.preventDefault();
                      addItem({
                        id: `bestseller-${product.id}`,
                        productId: product.productId,
                        name: product.name,
                        price: product.price,
                        originalPrice: product.originalPrice,
                        image: product.image,
                        category: product.category,
                        inStock: true
                      });
                      openCart();
                    }}
                    className="w-full bg-terracotta-brown text-white py-3 rounded-lg hover:bg-deep-espresso transition-all duration-300 font-medium transform hover:scale-105 shadow-md hover:shadow-lg"
                  >
                    Add to Cart
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Product Gallery */}
      <section className="py-16 bg-warm-cream">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <h2 className="font-playfair text-4xl font-bold text-deep-espresso mb-4 md:mb-0 tracking-wide">
              Product Gallery
            </h2>
            
            {/* Filter Buttons */}
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-full font-inter text-sm font-medium transition-all duration-300 ${
                  selectedCategory === 'all' 
                    ? 'bg-terracotta-brown text-white shadow-lg' 
                    : 'bg-white text-deep-espresso hover:bg-golden-tan hover:text-white'
                }`}
              >
                All Products
              </button>
              {categories.map((category) => (
                <button 
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-full font-inter text-sm font-medium transition-all duration-300 ${
                    selectedCategory === category.id 
                      ? 'bg-terracotta-brown text-white shadow-lg' 
                      : 'bg-white text-deep-espresso hover:bg-golden-tan hover:text-white'
                  }`}
                >
                  {category.icon} {category.name}
                </button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <Link key={product.id} to={`/product/${product.productId}`} className="group bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-3 transition-all duration-300 hover:shadow-2xl border border-gray-100 block">
                {/* Product Image */}
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {product.isNew && (
                      <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                        NEW
                      </span>
                    )}
                    <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                      {product.discount}
                    </span>
                  </div>
                </div>
                
                {/* Product Info */}
                <div className="p-6">
                  <h3 className="font-playfair text-xl font-bold text-deep-espresso mb-3 tracking-wide group-hover:text-deep-red-clay transition-colors">
                    {product.name}
                  </h3>
                  
                  {/* Pricing */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <span className="font-inter text-xl font-bold text-deep-red-clay">
                        {product.price}
                      </span>
                      <span className="font-inter text-sm text-gray-400 line-through">
                        {product.originalPrice}
                      </span>
                    </div>
                  </div>
                  
                  {/* Action Button */}
                  <button 
                    onClick={(e) => {
                      e.preventDefault();
                      addItem({
                        id: `product-${product.id}`,
                        productId: product.productId,
                        name: product.name,
                        price: product.price,
                        originalPrice: product.originalPrice,
                        image: product.image,
                        category: product.category,
                        inStock: true
                      });
                      openCart();
                    }}
                    className="font-inter w-full bg-deep-red-clay text-white py-3 rounded-lg hover:bg-terracotta-brown transition-all duration-300 font-medium transform hover:scale-105 shadow-md hover:shadow-lg"
                  >
                    Add to Cart
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ShopPage;
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import ScraftLogo from './ScraftLogo';
import Footer from './Footer';
import ChatBot from './ChatBot';
import CartIcon from './CartIcon';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const location = useLocation();
  
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-warm-cream font-inter">
      <header className="bg-white bg-opacity-20 backdrop-blur-md border-b border-white border-opacity-20 shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center">
              <ScraftLogo size="md" />
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex space-x-8">
              <Link 
                to="/"
                className={`font-inter hover:text-terracotta-brown transition-colors font-medium ${
                  location.pathname === '/' ? 'text-terracotta-brown' : 'text-deep-espresso'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/shop"
                className={`font-inter hover:text-terracotta-brown transition-colors font-medium ${
                  location.pathname === '/shop' ? 'text-terracotta-brown' : 'text-deep-espresso'
                }`}
              >
                Shop Now
              </Link>
              {location.pathname === '/' && (
                <>
                  <button 
                    onClick={() => scrollToSection('festival-sales')}
                    className="font-inter text-deep-espresso hover:text-terracotta-brown transition-colors font-medium"
                  >
                    Festival Sales
                  </button>
                  <button 
                    onClick={() => scrollToSection('about')}
                    className="font-inter text-deep-espresso hover:text-terracotta-brown transition-colors font-medium"
                  >
                    About
                  </button>
                </>
              )}
            </nav>

            {/* Right side buttons */}
            <div className="flex items-center space-x-4">
              {/* Cart Button */}
              <CartIcon />

              {/* Profile Button */}
              <Link 
                to="/profile" 
                className={`p-2 transition-colors ${
                  location.pathname === '/profile' ? 'text-terracotta-brown' : 'text-deep-espresso hover:text-terracotta-brown'
                }`}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </Link>

              {/* Mobile menu button */}
              <button className="md:hidden p-2 text-deep-espresso">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main>{children}</main>
      
      <Footer />
      
      {/* Floating ChatBot */}
      <ChatBot />
    </div>
  );
};

export default Layout;

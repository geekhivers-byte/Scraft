import React from 'react';
import { Link } from 'react-router-dom';
import artisanWorkshop from '../assets/artisan-workshop.jpg';

const Hero: React.FC = () => {
  return (
    <div id="hero" className="relative h-screen bg-cover bg-center" style={{ 
      backgroundImage: `url(${artisanWorkshop})` 
    }}>
      <div className="absolute inset-0 bg-deep-espresso bg-opacity-50"></div>
      <div className="relative z-10 flex flex-col items-start justify-center h-full pl-16 text-warm-cream">
        <h1 className="font-playfair text-6xl font-bold mb-4 drop-shadow-lg leading-tight tracking-wide">Threads of Tradition, Woven for Today</h1>
        <p className="font-inter text-xl mb-8 max-w-2xl drop-shadow-md font-light">Discover handcrafted textiles and stories from artisans across India.</p>
        <div className="flex gap-4">
          <Link 
            to="/shop"
            className="bg-orange-500 bg-opacity-20 border border-orange-400 border-opacity-60 backdrop-blur-md text-white font-bold py-3 px-6 rounded relative overflow-hidden shadow-lg transition-all duration-300 hover:bg-orange-400 hover:bg-opacity-30 hover:shadow-xl hover:-translate-y-1 group inline-block"
          >
            Explore Products
            <span className="absolute top-0 left-0 w-full h-full bg-gradient-to-l from-transparent via-orange-300 to-transparent opacity-40 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></span>
          </Link>
          <button className="bg-white bg-opacity-20 border border-white border-opacity-40 backdrop-blur-md text-white font-bold py-3 px-6 rounded relative overflow-hidden shadow-lg transition-all duration-300 hover:bg-opacity-30 hover:shadow-xl hover:-translate-y-1 group">
            Meet Our Artisans
            <span className="absolute top-0 left-0 w-full h-full bg-gradient-to-l from-transparent via-white to-transparent opacity-30 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
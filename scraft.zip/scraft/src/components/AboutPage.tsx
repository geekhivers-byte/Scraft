import React from 'react';
import { Link } from 'react-router-dom';
import artisanWorkshop from '../assets/artisan-workshop.jpg';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-warm-cream">
      {/* Breadcrumb */}
      <div className="bg-deep-espresso bg-opacity-5 py-4">
        <div className="container mx-auto px-4">
          <nav className="flex items-center space-x-2 text-sm text-deep-espresso">
            <Link to="/" className="hover:text-terracotta-brown transition-colors">Home</Link>
            <span>›</span>
            <span className="font-medium">About Us</span>
          </nav>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-deep-espresso to-terracotta-brown text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-playfair text-5xl font-bold mb-6 tracking-wide">About Scraft</h1>
          <p className="font-inter text-xl max-w-3xl mx-auto leading-relaxed">
            Celebrating the artistry of traditional Indian craftsmanship. Each piece tells a story of heritage, skill, and passion.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-playfair text-3xl font-bold text-deep-espresso mb-6">Our Story</h2>
              <div className="space-y-4 font-inter text-gray-700 leading-relaxed">
                <p>
                  Scraft was born from a deep appreciation for India's rich artisanal heritage. We believe that every handcrafted piece carries within it the soul of its creator, the wisdom of generations, and the beauty of traditional techniques.
                </p>
                <p>
                  Our journey began with a simple mission: to bridge the gap between skilled artisans and conscious consumers who value authenticity, quality, and the stories behind beautiful objects.
                </p>
                <p>
                  Today, we work directly with artisan communities across India, ensuring fair trade practices and helping preserve traditional crafts for future generations.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src={artisanWorkshop} 
                alt="Artisan at work" 
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-golden-tan bg-opacity-20">
        <div className="container mx-auto px-4">
          <h2 className="font-playfair text-3xl font-bold text-center text-deep-espresso mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-terracotta-brown rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
              </div>
              <h3 className="font-playfair text-xl font-bold text-deep-espresso mb-2">Authenticity</h3>
              <p className="font-inter text-gray-600">Every piece is genuinely handcrafted using traditional techniques passed down through generations.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-terracotta-brown rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <h3 className="font-playfair text-xl font-bold text-deep-espresso mb-2">Fair Trade</h3>
              <p className="font-inter text-gray-600">We ensure artisans receive fair compensation for their skills and craftsmanship.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-terracotta-brown rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V7h10v2z"/>
                </svg>
              </div>
              <h3 className="font-playfair text-xl font-bold text-deep-espresso mb-2">Sustainability</h3>
              <p className="font-inter text-gray-600">We promote eco-friendly practices and sustainable production methods.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;